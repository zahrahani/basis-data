-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2025 at 01:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `transaksipeminjaman`
--

CREATE TABLE `transaksipeminjaman` (
  `id_transaksi` int(11) NOT NULL,
  `nama_anggota` varchar(100) NOT NULL,
  `jurusan_anggota` varchar(50) NOT NULL DEFAULT 'Umum',
  `judul_buku` varchar(100) NOT NULL,
  `penerbit_buku` varchar(50) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date DEFAULT NULL,
  `denda` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksipeminjaman`
--

INSERT INTO `transaksipeminjaman` (`id_transaksi`, `nama_anggota`, `jurusan_anggota`, `judul_buku`, `penerbit_buku`, `tgl_pinjam`, `tgl_kembali`, `denda`) VALUES
(1, 'Jo Jahyeon', 'Informatika', 'The Circle', 'Knopf', '2025-03-01', '2025-03-03', 0),
(2, 'Jake Kim', 'Umum', 'Snow Crash', 'Bantam Books', '2025-03-01', '2025-03-05', 0),
(3, 'Yoon Minwoo', 'Sistem Informasi', 'Basis Data', 'Andi Publisher', '2025-03-02', '2025-03-05', 0),
(4, 'Yoon Minwoo', 'Sistem Informasi', 'The Circle', 'Knopf', '2025-03-02', '2025-03-06', 0),
(5, 'Jo Jahyeon', 'Informatika', 'NoSQL Distilled', 'Addison-Wesley', '2025-03-04', '2025-03-06', 0),
(6, 'Jake Kim', 'Umum', 'MySQL Crash Course', 'No Starch Press', '2025-03-10', '2025-03-16', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transaksipeminjaman`
--
ALTER TABLE `transaksipeminjaman`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transaksipeminjaman`
--
ALTER TABLE `transaksipeminjaman`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
