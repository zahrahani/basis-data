-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2025 at 09:08 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistempt`
--

-- --------------------------------------------------------

--
-- Table structure for table `ambilmk`
--

CREATE TABLE `ambilmk` (
  `NIM` char(5) NOT NULL,
  `Kode_MK` char(5) NOT NULL,
  `Nilai` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ambilmk`
--

INSERT INTO `ambilmk` (`NIM`, `Kode_MK`, `Nilai`) VALUES
('22001', 'IF101', 'A'),
('22001', 'IF102', 'B+'),
('22002', 'IF101', 'A-'),
('22003', 'SI201', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `dosen`
--

CREATE TABLE `dosen` (
  `NIDN` char(5) NOT NULL,
  `NamaDos` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dosen`
--

INSERT INTO `dosen` (`NIDN`, `NamaDos`) VALUES
('D001', 'Dr. Budi'),
('D002', 'Dr. Siti');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `NIM` char(5) NOT NULL,
  `NamaMhs` varchar(100) NOT NULL,
  `Prodi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`NIM`, `NamaMhs`, `Prodi`) VALUES
('22001', 'Andi Wijaya', 'Informatika'),
('22002', 'Rina Lestari', 'Informatika'),
('22003', 'Dika Pratama', 'Sistem Informasi');

-- --------------------------------------------------------

--
-- Table structure for table `matakuliah`
--

CREATE TABLE `matakuliah` (
  `Kode_MK` char(5) NOT NULL,
  `NamaMK` varchar(50) NOT NULL,
  `SKS` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `matakuliah`
--

INSERT INTO `matakuliah` (`Kode_MK`, `NamaMK`, `SKS`) VALUES
('IF101', 'Basis Data', 3),
('IF102', 'Pemrograman', 4),
('SI201', 'Manajemen Proyek', 3);

-- --------------------------------------------------------

--
-- Table structure for table `perkuliahan`
--

CREATE TABLE `perkuliahan` (
  `Kode_MK` char(5) NOT NULL,
  `NIDN` char(5) NOT NULL,
  `Ruang_Kelas` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `perkuliahan`
--

INSERT INTO `perkuliahan` (`Kode_MK`, `NIDN`, `Ruang_Kelas`) VALUES
('IF101', 'D001', 'A101'),
('IF102', 'D002', 'B202'),
('SI201', 'D001', 'C303');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ambilmk`
--
ALTER TABLE `ambilmk`
  ADD KEY `NIM` (`NIM`),
  ADD KEY `Kode_MK` (`Kode_MK`);

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`NIDN`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`NIM`);

--
-- Indexes for table `matakuliah`
--
ALTER TABLE `matakuliah`
  ADD PRIMARY KEY (`Kode_MK`);

--
-- Indexes for table `perkuliahan`
--
ALTER TABLE `perkuliahan`
  ADD KEY `Kode_MK` (`Kode_MK`),
  ADD KEY `NIDN` (`NIDN`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ambilmk`
--
ALTER TABLE `ambilmk`
  ADD CONSTRAINT `ambilmk_ibfk_1` FOREIGN KEY (`NIM`) REFERENCES `mahasiswa` (`NIM`),
  ADD CONSTRAINT `ambilmk_ibfk_2` FOREIGN KEY (`Kode_MK`) REFERENCES `matakuliah` (`Kode_MK`);

--
-- Constraints for table `perkuliahan`
--
ALTER TABLE `perkuliahan`
  ADD CONSTRAINT `perkuliahan_ibfk_1` FOREIGN KEY (`Kode_MK`) REFERENCES `matakuliah` (`Kode_MK`),
  ADD CONSTRAINT `perkuliahan_ibfk_2` FOREIGN KEY (`NIDN`) REFERENCES `dosen` (`NIDN`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
