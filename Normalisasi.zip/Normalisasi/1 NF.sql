-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2025 at 06:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistempt`
--

-- --------------------------------------------------------

--
-- Table structure for table `dataakademik`
--

CREATE TABLE `dataakademik` (
  `NIM` char(5) NOT NULL,
  `NamaMhs` varchar(100) NOT NULL,
  `Prodi` varchar(50) NOT NULL,
  `Kode_MK` char(5) NOT NULL,
  `NamaMK` varchar(50) NOT NULL,
  `SKS` int(11) NOT NULL,
  `NamaDos` varchar(50) NOT NULL,
  `Ruang_Kelas` varchar(20) NOT NULL,
  `Nilai` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dataakademik`
--

INSERT INTO `dataakademik` (`NIM`, `NamaMhs`, `Prodi`, `Kode_MK`, `NamaMK`, `SKS`, `NamaDos`, `Ruang_Kelas`, `Nilai`) VALUES
('22001', 'Andi Wijaya', 'Informatika', 'IF101', 'Basis Data', 3, 'Dr. Budi', 'A101', 'A'),
('22001', 'Andi Wijaya', 'Informatika', 'IF102', 'Pemrograman', 4, 'Dr. Siti', 'B202', 'B+'),
('22003', 'Dika Pratama', 'Sistem Informasi', 'SI201', 'Manajemen Proyek', 3, 'Prof. Budi', 'C303', 'B'),
('22004', 'Zahra Nibras', '', '', '', 0, '', '', ''),
('', '', '', 'IF103', 'Struktur Data', 3, '', '', ''),
('', '', '', '', '', 0, 'Prof. Hani', '', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
